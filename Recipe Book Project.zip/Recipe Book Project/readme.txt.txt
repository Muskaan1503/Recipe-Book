Recipe Book Web App

This is a simple recipe book website using HTML, CSS, and JavaScript.
Features:
- Add recipes with ingredients, steps, and image
- View recipes
- Search recipes